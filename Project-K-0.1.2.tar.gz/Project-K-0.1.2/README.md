# Project-K

This senior design project aims to simulate the Anti-Radiation Missile System AGM-88, which is widely used by various countries. It is most recently known for its application in the Russia-Ukraine war.

Built with Unity 2022.1.14f in C#
